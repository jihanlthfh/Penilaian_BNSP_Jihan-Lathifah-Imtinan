<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class AuthorSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
    \App\Models\Author::create(['name' => 'Tere Liye', 'bio' => 'Penulis Indonesia terkenal']);
    \App\Models\Author::create(['name' => 'Andrea Hirata', 'bio' => 'Penulis Laskar Pelangi']);
    \App\Models\Author::create(['name' => 'Pramoedya', 'bio' => 'Sastrawan besar Indonesia']);
    \App\Models\Author::create(['name' => 'Habiburrahman', 'bio' => 'Penulis religi']);
    \App\Models\Author::create(['name' => 'Dee Lestari', 'bio' => 'Penulis dan penyanyi']);
}
}
