<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class BookSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
{
    \App\Models\Book::create([
        'title' => 'Bumi',
        'author_id' => 1,
        'price' => 80000
    ]);

    \App\Models\Book::create([
        'title' => 'Laskar Pelangi',
        'author_id' => 2,
        'price' => 75000
    ]);

    \App\Models\Book::create([
        'title' => 'Bumi Manusia',
        'author_id' => 3,
        'price' => 90000
    ]);

    \App\Models\Book::create([
        'title' => 'Ayat-Ayat Cinta',
        'author_id' => 4,
        'price' => 85000
    ]);

    \App\Models\Book::create([
        'title' => 'Supernova',
        'author_id' => 5,
        'price' => 95000
    ]);
}
}
